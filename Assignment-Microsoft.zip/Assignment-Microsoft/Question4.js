//4): Write a function to reverse every word of a string.

// 1)using Using split and reverse Methods
function reverseString(str) {
    return str.split("").reverse().join("");
}
reverseString("Rakesh");

//Output: hsekaR

// 2) Without using split and reverse 
function withoutBuiltinreverse(str){
  let rversewords = "";    
  for (var i = str.length - 1; i >= 0; i--){        
    rversewords += str[i];
  }    
  return rversewords;
}
withoutBuiltinreverse("Rakeshst")
//Output: tshsekaR