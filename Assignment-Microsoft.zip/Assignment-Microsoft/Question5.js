//5): Write a function to remove duplicate strings from an array of strings.
using  Functions
let myArray = ["Rakesh","st","Rakesh","UI","st","Bangalore","Harman","Bangalore","Harman"]

function removeDuplicatearry(arr){
	let newarrEle =[];
	for(let i =1; i<arr.length; i++){
		if(newarrEle.indexOf(arr[i])== -1){

		newarrEle.push(arr[i])
		}

	}
	return newarrEle;
}

console.log(removeDuplicatearry(myArray));
